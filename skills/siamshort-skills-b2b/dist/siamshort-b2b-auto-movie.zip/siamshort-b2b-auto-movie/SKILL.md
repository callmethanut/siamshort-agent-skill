---
name: siamshort-b2b-auto-movie
description: >-
  "GEE Loop" — กระบวนการมาตรฐาน end-to-end ทำหนังบนแพลตฟอร์ม SiamShot/GEE ผ่าน
  siamshort MCP: จากบท/ไอเดีย → โปรเจกต์+world → cast/sets/props (+รูป) →
  sequences → shots (plot+tag+prompt) → gen วิดีโอทีละช็อต (human-in-the-loop)
  โดยสมมุติบทบาทเป็นทีมกำกับหนังระดับโลก. ใช้เมื่อผู้ใช้พิมพ์
  "/siamshort-b2b-auto-movie", "ทำหนังบน GEE/SiamShot", "เริ่ม Loop บน siamshort",
  "สร้างหนัง end to end", "auto movie", หรืออ้างถึง GEE Loop.
  คุม 2 เฟส: PHASE A pre-production (บท → ถาม pacing → สร้าง project+world →
  cast/sets/props + gen รูป → sequences + shots ครบ plot/duration/transition →
  TAG entity ทุกช็อต → prompt ทุกช็อต → สรุปให้ user confirm) และ PHASE B
  video-gen loop (gen 1 ช็อต → วิเคราะห์คลิป → รอ user OK → ช็อตถัดไป ห้ามข้าม
  gate). Do NOT trigger เมื่อ: ใช้แพลตฟอร์ม Fable เดิม (ใช้ /siamshort_auto_loop),
  แค่แปลงนิยาย→บท (ใช้ /siamshort-b2b-script-from-novel), หรือเล่นบน idea-board
  canvas อย่างเดียว (ใช้ canvas_* tools ตรงๆ).
---

# 🎬 SiamShot Auto-Movie — GEE Loop (end-to-end ผ่าน siamshort MCP)

กระบวนการเดียวกับ "Loop" ของ p'ton แต่ **ปรับให้ตรงกับแพลตฟอร์ม SiamShot/GEE ของเราเอง**
(siamshort MCP server) — จาก **บท → project+world → assets → sequences/shots → gen วิดีโอ
ทีละช็อต (human-in-the-loop)**.

> **สมมุติบทบาท = ทีมกำกับหนังระดับโลก** ตลอดกระบวนการ (Director / Story / Visual /
> Motion / Sound — spawn subagent ช่วยได้ แต่ห้ามข้าม OK-gate).
> ⭐ **คลังเทคนิค anti-slop เต็ม (ฉบับ GEE) = `reference/master-prompt-techniques.md` ของสกิลนี้
> — อ่านก่อนเขียน prompt storyboard/วิดีโอทุกครั้ง** (scene anchor อสมมาตร · CAM/BG+POSITION LOCK ·
> ข้อจำกัด Seedance §6 · continuity §9). ใช้คู่ `siamshort-b2b-anti-plastic` ·
> `siamshort-b2b-physics-guide` · `/siamshort-b2b-shot-continuity`.

---

## 📖 VOCABULARY MAP — เทียบศัพท์ Fable (สกิลเก่า) ↔ GEE (แพลตฟอร์มเรา)

| Fable (สกิลเก่า) | GEE / siamshort MCP | หมายเหตุ |
|---|---|---|
| character | **Cast** = entity_type `character` | `create_entity(entity_type:"character")` |
| scene (สถานที่) | **Set** = entity_type `scene` | `create_entity(entity_type:"scene")` |
| item | **Prop** = entity_type `item` | `create_entity(entity_type:"item")` |
| chapter | **Sequence** = `create_chapter` | 1 sequence มี `content` (เนื้อเรื่องท่อนนั้น) |
| **storybox** | **Shot** = `create_shot` | 1 shot = 1 beat = `plot` + `prompt` + `duration_seconds` + วิดีโอ 1 ตัว. Sequence 1 อัน มีหลาย shot |
| seedancePrompt | `studio_shots.prompt` | เขียนผ่าน `update_shot(prompt:...)` หรือ AI เขียนด้วย `generate_shot_prompt` |
| `update_shot(characterIds/sceneIds/itemIds)` | `character_ids` / `scene_id` / `item_ids` | ⭐ ของเรา **`create_shot` รับ tag ได้เลย** (update_shot ก็ได้) — scene ผูกได้ **1 ตัว** ต่อช็อต |
| mention `@char #scene $item` ในข้อความ | **mention_token** จาก `get_project` เช่น `@[โรส](cast:uuid)` `#[คลับ](set:uuid)` `$[มีด](prop:uuid)` | เซิร์ฟเวอร์แปลงเป็น syntax ของแต่ละโมเดลเอง — ❌ ห้ามเขียน `@image_file_N`/`【@图片N】` เอง |
| `regen_shot_video` + `poll_video_byteplus` | `generate_shot_video` + `wait_for_run` / `get_run_status` | ผลลัพธ์ = mp4 + signed URL (หมดอายุ ~1 ชม. → ต่ออายุด้วย `get_asset_url`) |
| `%ref` / `capture_video_frame` / `trim_reference_video` | ❌ **ยังไม่มีใน GEE MCP** | ใช้แทนด้วย: draft image (`generate_shot_image`) เป็น visual anchor + `transition_to_next:"extend"` + mention/tag ; frame-ref จะตามมาเฟสหน้า |
| storyboard-sheet / manhwa | ❌ ไม่ทำใน Loop | เหมือนสกิลเก่า — จบ PHASE A ที่ shots+tag+prompt+assets |

**ฟิลด์ภายใน 1 storybox ↔ 1 shot (GEE `studio_shots`):**

| ฟิลด์ Fable storybox | ฟิลด์ GEE | เขียน/สร้างด้วย |
|---|---|---|
| ข้อความ storybox / `presetText` (action+timing+กล้อง) | `plot` | `create_shot` / `update_shot` |
| `seedancePrompt` | `prompt` | `update_shot` / `generate_shot_prompt` |
| **storyboard image** | `image_path` = **draft still ของช็อต** ✅ | `generate_shot_image(shot_id)` (compose จาก plot + world + portrait ของ entity ที่ tag) หรืออัปโหลดในเว็บ |
| **manhwa image** | **Mix Stage** (entity_type `mix_stage`) ✅ | gen สไตล์การ์ตูนด้วย `canvas_generate_image` → `save_to_mix_stage(project_id, name, run_id)` → แนบเข้าช็อตด้วย `set_shot_mix_stage_refs(shot_id, mix_stage_ids, start/end_frame?)` → `generate_shot_video` ดึงเป็น ref อัตโนมัติ |
| วิดีโอ / takes | `video_path` + ประวัติทุก take ใน ai_runs (`list_runs(studio_shot_id)`) ; **เลือก take = เว็บ UI เท่านั้น** | `generate_shot_video` |
| duration | `duration_seconds` | `create_shot` / `update_shot` |
| — (Fable ไม่มี) | `transition_to_next` (`extend`/`jump`) — hint ต่อเนื่องเฟรมข้ามช็อต | `create_shot` / `update_shot` |

---

## 0) กฎเปิดสกิล (ทำก่อนเสมอ)

1. **สวมบททีมกำกับระดับโลก** — ทุก decision (มุมกล้อง / blocking / แสง / จังหวะ) คิดแบบมืออาชีพ.
2. **อ่าน `reference/gee-platform-map.md` ของสกิลนี้** — พารามิเตอร์จริง + ข้อจำกัด + gotchas
   ของแพลตฟอร์มเรา (ratio ที่ระบบรับ, โมเดลที่พิสูจน์แล้ว, กติกา points).
   เทคนิค prompt เชิง craft → `reference/master-prompt-techniques.md` (ฉบับ GEE ในสกิลนี้).
3. ⛔ **กฎเหล็ก — ทุกการ gen (รูป/prompt/วิดีโอ) ผ่าน siamshort MCP เท่านั้น**
   (`generate_entity_image` · `generate_shot_image` · `generate_shot_prompt` ·
   `generate_shot_video` · `start_video_prompt_chain`). ❌ ห้ามยิง provider ตรง /
   ห้ามใช้สกิล gen รูปภายนอก — รูปนอก MCP ไม่ลงทะเบียนในโปรเจกต์ = mention/tag/continuity พัง.
4. ⛔⛔ **กฎเหล็ก TAG — ทุก shot ต้องผูก entity จริง ไม่ใช่แค่พิมพ์ชื่อ:**
   ตอน `create_shot`/`create_shots_batch` ใส่ `character_ids:[...]`, `scene_id:"..."`,
   `item_ids:[...]` ให้ครบทุกช็อต (หรือ `update_shot` ตามหลัง). Tag = ref รูป ambient
   ตอน gen วิดีโอ ; mention_token ใน prompt = ref แบบระบุตัวชัด. **ใช้ทั้งคู่**:
   tag ทุกตัวที่อยู่ในช็อต + mention เฉพาะตัวที่ต้องการให้ model bind ชัดๆ.
5. **เช็ค `get_balance` ก่อนเริ่ม PHASE ใหญ่** — gen ตัดแต้มตอนเริ่ม (fail คืนอัตโนมัติ).
   บอก user คร่าวๆ ว่าแผนนี้กินประมาณกี่แต้ม (ดูราคา `list_models` + ตารางใน reference).
6. **ทุก id สำคัญ (project/chapter/shot/entity/run) จดไว้ในบทสนทนา** — tool อื่นต้องใช้ต่อ.

---

## PHASE A — PRE-PRODUCTION (บท → project → assets → shots ครบ prompt+tag)

1. **รับบท/ไอเดีย → บทถ่ายทำละเอียด** — ถ้ามีนิยาย/บทยาว ใช้ `/siamshort-b2b-script-from-novel`
   ก่อน (ได้ △-format = source of truth). ไอเดียสั้น → ทีมกำกับ (subagent 5 role) ขยายเอง
   แล้วให้ user เห็นก่อน.
2. **ถาม PACING 3 ระดับ (รวดเร็ว/ปานกลาง/ยาว)** — เหมือน Loop เดิม: บทเท่ากัน ต่างที่วิธีแตก
   เป็น shot (⚡ น้อยสุด/ตัดฉับ · ▶ 1 shot = 1 beat · 🎬 แตก 1 action หลายมุม). เสนอ default
   ตามแนวเรื่อง แต่ **ให้ user ตัดสิน**.
3. **เสนอ graphic style 5 แบบ** จากบท → user เลือก → ยึดทั้งเรื่อง (ปรับแค่ฉาก/เวลา/แสง).
4. **สร้างโปรเจกต์:** `create_project(title, logline, genre, ratio, synopsis, visual_rules,
   era, atmosphere, film_style, ...)` — ⭐ **`synopsis` ต้องแน่น** (หลาย AI action ฝั่งเซิร์ฟเวอร์
   gate ด้วย world synopsis) ; `visual_rules` = graphic style + บล็อกข้อห้ามที่เลือก ;
   `ratio` ของโปรเจกต์ = ratio หลักของหนัง (แนวตั้ง = `9:16`).
5. **สร้าง Cast / Sets / Props:** `create_entity` ทีละตัว — `description` = **visual DNA
   ละเอียด ของ subject ล้วนๆ** (ภาษาอังกฤษ) เพราะเป็น prompt ตรงของรูป. 🎯 **CLEAN REF:**
   Cast = ตัวละครอย่างเดียว ❌ห้ามใส่ฉากหลัง/คนอื่นใน description · Prop = วัตถุเดี่ยว
   ❌ไม่มีมือ/โต๊ะ/ฉาก · Set = สถานที่ไม่มีคน — ระบบ gen พื้นหลัง clean reference /
   พื้นขาว studio / depopulated ให้เองอยู่แล้ว การใส่ฉากใน description จะตีกับ directive
   ของระบบ. ตอน QC: cast มีฉาก/คนแทรก · prop มีมือ/ฉาก · set มีคน = FAIL → regen.
   - Set = **eye-level WIDE establishing เฟรมเดียว** เห็นทุกโซน + anchor อสมมาตรชัด
     (ใส่ใน description) — ❌ ไม่ใช่ turnaround grid.
   - จากนั้น **gen รูปทุกตัว**: `generate_entity_image(entity_id)` → `wait_for_run` จนครบ.
     ยิงพร้อมกันได้ (ระบบมี queue ให้เอง — สถานะ `queued` = ปกติ รอต่อ). รูปไม่ผ่าน → แก้
     `update_entity(description)` แล้ว gen ใหม่ (≤3 ครั้ง/ตัว แล้วเอาตัวดีสุด).
5b. 📎 **user แนบไฟล์ ref = ต้องใช้ (รองรับทั้งรูปและวิดีโอ)**: `upload_reference(file_path)`
   → ใช้ผ่าน canvas gen หรือ `save_to_mix_stage(storage_path)` → `set_shot_mix_stage_refs`
   → ตอน gen ช็อต: **รูป → image_files (identity/ลุค) · คลิป → video_files (motion/จังหวะ)**
   อัตโนมัติ — กำกับใน prompt ว่าเอาอะไรจาก ref. รูปคนจริง ref วิดีโอ = MCP register
   virtual asset ให้อัตโนมัติ (byteplus+xskill) ; "still being registered" → รอ ~30 วิ เรียกซ้ำ.

6. **สร้าง Sequences:** `create_chapter(project_id, title, summary, content,
   duration_seconds)` — `content` = เนื้อเรื่องท่อนนั้นเต็มๆ (เป็น context ให้ AI เขียน prompt).
7. **ลง Shots (= storybox เดิม):** `create_shots_batch(chapter_id, shots:[...])` ตามลำดับบท —
   ต่อช็อต: `title` · `plot` (action+มุมกล้อง+position ละเอียด — **ยังไม่ใส่ graphic style** ;
   ปริมาณ action พอดีวินาที: 5 วิ = 1 จังหวะ, 10–15 วิ = 2–3 จังหวะ) ·
   `duration_seconds` (**4–15 วิ/ช็อต เท่านั้น — ผลรวมทุกช็อต ≈ target ของหนัง**;
   target 60 วิ → 6–10 ช็อต) · `transition_to_next` (`extend` = เฟรมท้ายต่อเนื่องไปช็อตถัดไป /
   `jump` = ตัดฉาก) · ⭐ **tag `character_ids` / `scene_id` / `item_ids` ให้ครบตั้งแต่ตอนสร้าง**.
   - **เปิดทุก location ใหม่ด้วย ESTABLISHING SHOT** (ไม่มีคน บอกที่+เวลา).
   - ⚠️ **ลำดับช็อตถูกกำหนดตอนสร้าง** — MCP ยังไม่มี tool แทรก/สลับลำดับ → **วางแผนให้จบ
     ก่อนค่อย create**. ตกช็อต = เพิ่มท้าย sequence ได้อย่างเดียว (แล้วเล่าตามบทตอน gen แทน).
   - ช็อตมีแรงตั้งต้น (ของตก/แตก/สาด/ล้ม/ชน) → ขยายด้วย `siamshort-b2b-physics-guide` ก่อนเขียน plot.
8. **เขียน prompt ทุกช็อต — 2 ทาง (เลือก/ผสม):**
   - **ทาง AI (แนะนำเริ่มต้น):** `start_video_prompt_chain(project_id)` — ระบบไล่เขียน
     prompt ให้ทุกช็อตที่มี plot แบบ **ต่อเนื่องช็อตต่อช็อต** ฝั่งเซิร์ฟเวอร์ (ปิดจอได้) →
     poll `get_chain_job_status(project_id)` จน completed แล้ว review ทีละช็อต.
     ⚠️ chain มีได้ 1 ตัว/โปรเจกต์ ; ต้องรอ n8n cron หยิบ (~5 นาที).
   - **ทางมือ (คุมเองเต็มที่):** `update_shot(shot_id, prompt:"...")` — ใส่
     **mention_token** จาก `get_project` (`@[ชื่อ](cast:id)` ฯลฯ) ตรงตำแหน่งที่ตัวละคร/
     ฉาก/พร็อพปรากฏ + scene-lock + position-lock + anti-slop ตาม MASTER.
     เซิร์ฟเวอร์แปลง token → ref รูป + syntax ต่อโมเดลเองทั้งหมด.
     ✍️ **เขียนทีละช็อตตามลำดับเรื่องเสมอ ห้าม batch** — video prompt ของจริงยาวมาก:
     อ่าน plot + เฟรมท้ายช็อต i-1 → เขียนช็อต i จบลึก → `update_shot` ทันที → ค่อยช็อต
     i+1. เขียนขนานหลายช็อต = prompt ตื้น continuity หลุด (chain ฝั่งเซิร์ฟเวอร์ก็ไล่
     ทีละช็อตด้วยเหตุผลเดียวกัน).
9. **DOUBLE-CHECK กับบท** — `get_project` ดึงทั้งหมดมาตรวจ: ครบทุก beat? tag ครบทุกช็อต?
   prompt ตรง plot? → **สรุปภาพรวมให้ user** (กี่ sequence · กี่ shot · กี่ตัวละคร · เรื่องย่อ
   ต่อช็อต · แต้มที่จะใช้ต่อวิดีโอ) → **รอ user confirm**. user ขอแก้ → ตรวจกับบททุกครั้ง ;
   ถ้าแก้แล้วไม่ตรงบท → เตือนก่อน.
10. **(optional แต่ช่วยมาก) gen draft image ช็อตสำคัญ:** `generate_shot_image(shot_id)`
    (ใช้ plot compose ฝั่งเซิร์ฟเวอร์ + แปะ portrait ของ entity ที่ tag ไว้) — ได้ storyboard
    still เป็น visual anchor + ให้ user เห็นทิศทางก่อนเผาแต้มวิดีโอ. **จบ PHASE A.**

---

## PHASE B — VIDEO-GEN LOOP (ทีละช็อต · human-in-the-loop · ห้ามข้าม gate)

> ⛔ **กฎเหล็ก: gen 1 ช็อต → STOP รอ user OK → ค่อยช็อตถัดไป. ห้าม batch.**

วนต่อช็อต N:

1. **วิเคราะห์ช็อตก่อนหน้า (N−1) ก่อนเสมอ** — เอา signed URL วิดีโอช็อตก่อน (จาก
   `get_run_status` / `list_runs` ; URL เก่าหมดอายุ → `get_asset_url(storage_path)`)
   → ดาวน์โหลด → **วิเคราะห์ทั้งคลิป** (ffmpeg grid 16 เฟรม `fps=1, tile=4x4` + เฟรมเต็ม
   จุดสำคัญ — อย่าเชื่อเฟรมท้ายอย่างเดียว) → อ่าน **position นักแสดงทุกคน + แสง + CONTINUITY
   NOTE** (เศษ/คราบ/ของล้ม ต้องอยู่ต่อช็อตถัดไป). *(ช็อตแรกของซีน → ใช้ draft image + Set ref แทน)*
2. **ล็อก prompt ช็อต N:** `update_shot(shot_id, prompt:...)` ตามผลวิเคราะห์ —
   scene-lock + position-lock + anti-slop + mention_token ครบ. เลี่ยงเปิด 0s ด้วย
   ตัวละคร/มุมเดียวกับ last frame ช็อตก่อน (กัน model ก๊อปเฟรมแปะ).
3. **gen วิดีโอ:** `generate_shot_video(shot_id, model, ratio, resolution, duration)` —
   ค่าแนะนำอยู่ใน `reference/gee-platform-map.md` (โมเดล/ratio/แต้ม). ระบบใช้ prompt
   ที่เซฟไว้ + tag + mention อัตโนมัติ.
4. **poll:** `wait_for_run(run_id, timeout_s:55)` วนจน terminal (วิดีโอ = หลายนาที ;
   `queued` = รอคิว ปกติ). ได้ mp4 signed URL.
5. **วิเคราะห์คลิปเต็ม (เหมือนข้อ 1)** เช็ค: position ถูก · ไม่เพี้ยน/ไม่โคลน/ไม่แบ่งจอ ·
   ฉากตรง ref · ratio ถูก · ความยาวครบ.
6. **STOP → ส่งวิดีโอ + ผลวิเคราะห์ให้ user "โอเคไหม / แก้ไหม?"**
   - ❌ ไม่ผ่าน → หาสาเหตุ → แก้ prompt เฉพาะจุด → `generate_shot_video` ใหม่ (**≤4 ครั้ง/ช็อต**
     ครบแล้วเอาตัวดีสุด ให้ user เลือก) → ถามใหม่. **ห้ามไปช็อตถัดไปจนกว่า user OK.**
7. **user OK → ช็อต N+1** (กลับข้อ 1). วนจนจบเรื่อง — ทุกช็อตมี OK-gate เสมอ.

---

## ✅ QUICK CHECKLIST ก่อน gen ทุกช็อต (ย่อ — เต็มดู MASTER + reference)

- [ ] shot นี้ **tag** `character_ids`/`scene_id`/`item_ids` ครบ (ดูจาก `get_project`)
- [ ] prompt มี **mention_token** ของตัวที่ต้อง bind ชัด (❌ ไม่เขียน syntax provider เอง)
- [ ] SCENE อ้าง **ABSOLUTE landmark** ของ Set ref (❌ ซ้าย/ขวาตามกล้อง ❌ มโนเฟอร์นิเจอร์)
- [ ] **CAM/BG + POSITION LOCK** ต่อเนื่องจากผลวิเคราะห์ช็อตก่อน ; ❌ สลับฝั่ง A↔B
- [ ] MEDIUM/MCU เป็นหลัก · กล้อง eye-level · ❌ overhead/CCTV
- [ ] [ANTI-CLONE] นับตัว "EXACTLY N" · [ANTI-SPLIT] ❌ แบ่งจอ/grid
- [ ] ตัวหนังสือบนภาพ = อังกฤษเท่านั้น · กันขาตั้งกล้อง/rig โผล่ (cameraOverride)
- [ ] แรงตั้งต้น → ลูกโซ่ฟิสิกส์ครบ + CONTINUITY NOTE ช็อตก่อนยังอยู่
- [ ] `transition_to_next` ตั้งถูก (extend/jump) · duration/ratio อยู่ในสเปกโมเดล
- [ ] แต้มพอ (`get_balance`) — วิดีโอ ~20-40 pt/ช็อต ตาม duration/resolution

---

## เครื่องมือ GEE MCP ที่สกิลนี้ใช้ (ครบชุด)

`list_projects` · `get_project` (มี mention_token) · `get_balance` · `list_models` ·
`list_runs` · `get_asset_url` · `create_project` · `update_world` · `set_project_cover` · `create_chapter` ·
`create_shot` / `create_shots_batch` · `update_shot` · `create_entity` / `update_entity` ·
`generate_entity_image` · `generate_shot_image` · `generate_shot_prompt` ·
`generate_shot_video` · `get_run_status` · `wait_for_run` · `start_video_prompt_chain` ·
`get_chain_job_status` (+ `canvas_*` สำหรับ mood-board — นอก scope Loop นี้)

> ยังไม่มีใน MCP (อย่าเรียก): capture_video_frame · trim_reference_video · %ref ·
> delete/reorder shot · upscale. ต้องใช้ = แจ้ง user ให้ทำในเว็บ UI แทน.
